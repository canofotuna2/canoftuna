Controls for Sandboxels are listed underneath [the game](https://sandboxels.R74n.com).

Use the [feedback form](https://sandboxels.r74n.com/feedback) linked under the game for suggestions or bug reports. You can also join our [Discord server](https://discord.gg/ejUc6YPQuS) for support and everything else.

This isn't preferred, but you can also report issues on this GitHub repository [here](https://github.com/R74nCom/sandboxels/issues).

For help with creating mods, read the [Modding Tutorial](https://sandboxels.wiki.gg/wiki/Modding_tutorial).

For help with specific mods, the mod's creator is likely in the Discord. Ask around and you'll be directed to them.
