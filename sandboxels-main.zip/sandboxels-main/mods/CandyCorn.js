elements.candy.colorPattern = [
		"W","W","W","W","W",
		"O","O","O","O","O",
		"Y","Y","Y","Y","Y",
	]
	elements.candy.colorKey = {"W":"#ffffff", "Y":"#ffcd55", "O":"#ff9933"}
	elements.candy.color = ["#ffffff","#ffffff","#ff9933","#ff9933","#ffcd55","#ffcd55"]
	elements.candy.breakIntoColor = ["#ffffff","#ffcd55","#ff9933"]