testLibrary = {}

testLibrary.logElementDensity = function (element) {
    console.log(element + " density is " + elements[element].density);
}